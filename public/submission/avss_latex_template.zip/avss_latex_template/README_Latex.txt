
To make a sample AVSS paper, copy the contents of this directory
somewhere, and type

 latex egpaper_for_DoubleBlindReview

or 

 pdflatex egpaper_for_DoubleBlindReview


This MUST be used for double blind review. The paper MUST be anonymous.
